import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner analiseDeNumero = new Scanner(System.in);
        System.out.println("digite um numero : ");
        int numeroAnalise = analiseDeNumero.nextInt();

        String numeroStr = String.valueOf(Math.abs(numeroAnalise));
        int quantidadeNumeros = numeroStr.length();
        System.out.println("quantidade de digitos é " + quantidadeNumeros);
        if (quantidadeNumeros <= 4) {
            System.out.println("Esse numero está entre 1 e 4 digitos ");
        } else {
            System.out.println("Esse numero tem 5 ou mais digitos ");
        }

        analiseDeNumero.close();

    }
}